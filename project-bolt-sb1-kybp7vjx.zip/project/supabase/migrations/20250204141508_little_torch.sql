/*
  # Restaurant Application Schema

  1. New Tables
    - `restaurants`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `cuisines` (text[])
      - `average_cost_for_two` (numeric)
      - `currency` (text)
      - `has_table_booking` (boolean)
      - `has_online_delivery` (boolean)
      - `rating` (numeric)
      - `address` (text)
      - `locality` (text)
      - `city` (text)
      - `country` (text)
      - `latitude` (numeric)
      - `longitude` (numeric)
      - `featured_image` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Extensions
    - Enable PostGIS for location-based queries
    
  3. Security
    - Enable RLS on restaurants table
    - Add policies for public read access
*/

-- Enable PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- Create restaurants table
CREATE TABLE IF NOT EXISTS restaurants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  cuisines text[],
  average_cost_for_two numeric,
  currency text DEFAULT 'USD',
  has_table_booking boolean DEFAULT false,
  has_online_delivery boolean DEFAULT false,
  rating numeric,
  address text,
  locality text,
  city text,
  country text,
  latitude numeric,
  longitude numeric,
  featured_image text,
  location geography(POINT, 4326),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index for location-based queries
CREATE INDEX IF NOT EXISTS restaurants_location_idx ON restaurants USING GIST (location);

-- Create function to update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updating timestamp
CREATE TRIGGER update_restaurants_updated_at
    BEFORE UPDATE ON restaurants
    FOR EACH ROW
    EXECUTE PROCEDURE update_updated_at_column();

-- Enable RLS
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
  ON restaurants
  FOR SELECT
  TO public
  USING (true);

-- Create function for location-based search
CREATE OR REPLACE FUNCTION search_restaurants_by_location(
  lat double precision,
  lng double precision,
  radius_meters double precision
)
RETURNS SETOF restaurants
LANGUAGE sql
STABLE
AS $$
  SELECT *
  FROM restaurants
  WHERE ST_DWithin(
    location,
    ST_SetSRID(ST_MakePoint(lng, lat), 4326)::geography,
    radius_meters
  );
$$;