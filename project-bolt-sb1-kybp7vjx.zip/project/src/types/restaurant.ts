export interface Restaurant {
  id: string;
  name: string;
  description: string | null;
  cuisines: string[];
  average_cost_for_two: number;
  currency: string;
  has_table_booking: boolean;
  has_online_delivery: boolean;
  rating: number;
  address: string;
  locality: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  featured_image: string | null;
  created_at: string;
  updated_at: string;
}