import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, DollarSign } from 'lucide-react';
import type { Restaurant } from '../types/restaurant';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

export function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Link 
      to={`/restaurant/${restaurant.id}`}
      className="block bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
    >
      <div className="relative h-48 rounded-t-lg overflow-hidden">
        <img
          src={restaurant.featured_image || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-white px-2 py-1 rounded-full flex items-center gap-1">
          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          <span className="text-sm font-medium">{restaurant.rating.toFixed(1)}</span>
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{restaurant.name}</h3>
        <div className="flex items-center gap-2 text-gray-600 mb-2">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{restaurant.locality}, {restaurant.city}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <DollarSign className="w-4 h-4" />
          <span className="text-sm">
            {restaurant.average_cost_for_two} {restaurant.currency} for two
          </span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {restaurant.cuisines.slice(0, 3).map((cuisine) => (
            <span
              key={cuisine}
              className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full"
            >
              {cuisine}
            </span>
          ))}
        </div>
      </div>
    </Link>
  );
}