import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Star, DollarSign, Clock, Phone } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Restaurant } from '../types/restaurant';

export function RestaurantDetail() {
  const { id } = useParams<{ id: string }>();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadRestaurant(id);
    }
  }, [id]);

  async function loadRestaurant(restaurantId: string) {
    try {
      const { data, error } = await supabase
        .from('restaurants')
        .select('*')
        .eq('id', restaurantId)
        .single();

      if (error) throw error;
      setRestaurant(data);
    } catch (error) {
      console.error('Error loading restaurant:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-gray-600">Restaurant not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="relative h-96">
        <img
          src={restaurant.featured_image || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h1 className="text-4xl font-bold text-white mb-2">{restaurant.name}</h1>
          <div className="flex items-center gap-4 text-white">
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              <span>{restaurant.rating.toFixed(1)}</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1">
              <DollarSign className="w-5 h-5" />
              <span>{restaurant.average_cost_for_two} {restaurant.currency} for two</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-semibold mb-4">About</h2>
              <p className="text-gray-600 mb-6">{restaurant.description || 'No description available.'}</p>

              <h3 className="text-lg font-semibold mb-3">Cuisines</h3>
              <div className="flex flex-wrap gap-2 mb-6">
                {restaurant.cuisines.map((cuisine) => (
                  <span
                    key={cuisine}
                    className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm"
                  >
                    {cuisine}
                  </span>
                ))}
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3 text-gray-600">
                  <MapPin className="w-5 h-5" />
                  <span>{restaurant.address}</span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <Clock className="w-5 h-5" />
                  <div>
                    <p>Table Booking: {restaurant.has_table_booking ? 'Available' : 'Not available'}</p>
                    <p>Online Delivery: {restaurant.has_online_delivery ? 'Available' : 'Not available'}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="h-[400px] bg-gray-100 rounded-lg">
              {/* Map will be implemented here */}
              <div className="w-full h-full flex items-center justify-center text-gray-500">
                Map view coming soon
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}