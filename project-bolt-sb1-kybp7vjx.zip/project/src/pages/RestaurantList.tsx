import React, { useEffect, useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { RestaurantCard } from '../components/RestaurantCard';
import type { Restaurant } from '../types/restaurant';

export function RestaurantList() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [radius, setRadius] = useState('3000'); // Default 3km radius

  useEffect(() => {
    loadRestaurants();
  }, [searchQuery]);

  async function loadRestaurants() {
    try {
      let query = supabase
        .from('restaurants')
        .select('*');

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%,cuisines.cs.{${searchQuery}}`);
      }

      const { data, error } = await query.limit(20);

      if (error) throw error;
      setRestaurants(data || []);
    } catch (error) {
      console.error('Error loading restaurants:', error);
    } finally {
      setLoading(false);
    }
  }

  async function searchByLocation() {
    if (!latitude || !longitude) {
      alert('Please enter both latitude and longitude');
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .rpc('search_restaurants_by_location', {
          lat: parseFloat(latitude),
          lng: parseFloat(longitude),
          radius_meters: parseFloat(radius)
        });

      if (error) throw error;
      setRestaurants(data || []);
    } catch (error) {
      console.error('Error searching by location:', error);
      alert('Error searching by location. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col gap-8">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold text-gray-900">Restaurants</h1>
            
            {/* Text Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search restaurants by name, description, or cuisine..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Location Search */}
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Location Search
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="number"
                  placeholder="Latitude"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={latitude}
                  onChange={(e) => setLatitude(e.target.value)}
                />
                <input
                  type="number"
                  placeholder="Longitude"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={longitude}
                  onChange={(e) => setLongitude(e.target.value)}
                />
                <input
                  type="number"
                  placeholder="Radius (meters)"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  value={radius}
                  onChange={(e) => setRadius(e.target.value)}
                />
              </div>
              <button
                onClick={searchByLocation}
                className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Search by Location
              </button>
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : restaurants.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {restaurants.map((restaurant) => (
                <RestaurantCard key={restaurant.id} restaurant={restaurant} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-600">No restaurants found. Try adjusting your search criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}