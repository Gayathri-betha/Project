import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import csv from 'csv-parser';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

async function importRestaurants(filePath: string) {
  const results: any[] = [];

  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (data) => results.push(data))
    .on('end', async () => {
      for (const restaurant of results) {
        const { data, error } = await supabase
          .from('restaurants')
          .insert({
            name: restaurant.name,
            description: restaurant.description || '',
            cuisines: restaurant.cuisines?.split(',').map((c: string) => c.trim()) || [],
            average_cost_for_two: parseFloat(restaurant.average_cost_for_two) || 0,
            currency: restaurant.currency || 'USD',
            has_table_booking: restaurant.has_table_booking === 'Yes',
            has_online_delivery: restaurant.has_online_delivery === 'Yes',
            rating: parseFloat(restaurant.rating) || 0,
            address: restaurant.address,
            locality: restaurant.locality,
            city: restaurant.city,
            country: restaurant.country,
            latitude: parseFloat(restaurant.latitude),
            longitude: parseFloat(restaurant.longitude),
            featured_image: restaurant.featured_image,
            location: `POINT(${restaurant.longitude} ${restaurant.latitude})`
          });

        if (error) {
          console.error('Error importing restaurant:', error);
        }
      }
      console.log('Import completed!');
    });
}

// Usage
importRestaurants('./zomato-data.csv');